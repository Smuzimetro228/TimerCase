package timercase.storage;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import timercase.TimerCasePlugin;
import java.io.File;
import java.io.IOException;
import java.util.*;

public final class CaseStorage {
    private final TimerCasePlugin plugin;
    private final File file;
    private YamlConfiguration yaml;
    public CaseStorage(TimerCasePlugin plugin) { this.plugin = plugin; this.file = new File(plugin.getDataFolder(), "cases.yml"); }
    public void load() { if (!file.exists()) plugin.saveResource("cases.yml", false); yaml = YamlConfiguration.loadConfiguration(file); }
    public void save() { try { yaml.save(file); } catch (IOException e) { plugin.getLogger().severe("Не вдалося зберегти cases.yml: " + e.getMessage()); } }
    public String create(Location l) { String id = UUID.randomUUID().toString().substring(0,8); String p="cases."+id+"."; yaml.set(p+"world", l.getWorld().getName()); yaml.set(p+"x", l.getBlockX()); yaml.set(p+"y", l.getBlockY()); yaml.set(p+"z", l.getBlockZ()); yaml.set(p+"enabled", true); yaml.set(p+"refresh-time", plugin.getConfig().getInt("settings.default-refresh-time",300)); yaml.set(p+"deadline", 0L); yaml.set(p+"loot", new ArrayList<ItemStack>()); save(); return id; }
    public void remove(String id) { yaml.set("cases."+id,null); save(); }
    public Set<String> ids() { ConfigurationSection s=yaml.getConfigurationSection("cases"); return s==null?new LinkedHashSet<>():s.getKeys(false); }
    public Location location(String id) { String p="cases."+id+"."; var w=Bukkit.getWorld(yaml.getString(p+"world","")); return w==null?null:new Location(w,yaml.getInt(p+"x"),yaml.getInt(p+"y"),yaml.getInt(p+"z")); }
    public String find(Location l) { for(String id:ids()){Location c=location(id);if(c!=null&&c.getWorld().equals(l.getWorld())&&c.getBlockX()==l.getBlockX()&&c.getBlockY()==l.getBlockY()&&c.getBlockZ()==l.getBlockZ())return id;}return null; }
    public int refreshTime(String id) { return yaml.getInt("cases."+id+".refresh-time",300); }
    public void refreshTime(String id,int seconds) { yaml.set("cases."+id+".refresh-time",Math.max(1,seconds));save(); }
    public long deadline(String id) { return yaml.getLong("cases."+id+".deadline",0); }
    public void deadline(String id,long value) { yaml.set("cases."+id+".deadline",value);save(); }
    public boolean enabled(String id) { return yaml.getBoolean("cases."+id+".enabled",true); }
    public void enabled(String id,boolean value) { yaml.set("cases."+id+".enabled",value);save(); }
    public List<ItemStack> loot(String id) { List<?> raw=yaml.getList("cases."+id+".loot",List.of()); List<ItemStack> out=new ArrayList<>(); for(Object o:raw) if(o instanceof ItemStack i)out.add(i.clone()); return out; }
    public void loot(String id,List<ItemStack> items) { yaml.set("cases."+id+".loot",items);save(); }
}
