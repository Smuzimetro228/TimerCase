package timercase.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import timercase.TimerCasePlugin;
import timercase.manager.TimerManager;
import timercase.storage.CaseStorage;
import java.util.*;

public final class CaseGui implements Listener {
 private final TimerCasePlugin plugin; private final CaseStorage storage; private final TimerManager timers; private final NamespacedKey key; private final Map<UUID,String> editing=new HashMap<>(); private final Map<UUID,List<ItemStack>> drafts=new HashMap<>();
 public CaseGui(TimerCasePlugin p,CaseStorage s,TimerManager t){plugin=p;storage=s;timers=t;key=new NamespacedKey(p,"action");}
 public void openMain(Player p,int page){Inventory inv=Bukkit.createInventory(null,54,"§8TimerCase §7— §fСписок");List<String> ids=new ArrayList<>(storage.ids());int start=Math.max(0,page)*45;for(int i=start;i<Math.min(ids.size(),start+45);i++){String id=ids.get(i);var loc=storage.location(id);ItemStack item=new ItemStack(Material.CHEST);ItemMeta m=item.getItemMeta();m.setDisplayName("§6TimerCase §f"+id);m.setLore(List.of("§7Світ: §f"+(loc==null?"невідомо":loc.getWorld().getName()),"§7Координати: §f"+(loc==null?"-":loc.getBlockX()+", "+loc.getBlockY()+", "+loc.getBlockZ()),"§7Час: §f"+storage.refreshTime(id)+" сек.","§eНатисни для налаштувань"));m.getPersistentDataContainer().set(key,PersistentDataType.STRING,"case:"+id);item.setItemMeta(m);inv.setItem(i-start,item);}inv.setItem(49,button(Material.EMERALD,"§aСтворити сундук","create"));if(page>0)inv.setItem(45,button(Material.ARROW,"§eПопередня сторінка","page:"+(page-1)));if(start+45<ids.size())inv.setItem(53,button(Material.ARROW,"§eНаступна сторінка","page:"+(page+1)));p.openInventory(inv);}
 private void openSettings(Player p,String id){Inventory inv=Bukkit.createInventory(null,27,"§8TimerCase §7— §f"+id);inv.setItem(10,button(Material.CHEST,"§aРедактор луту","loot:"+id));inv.setItem(12,button(Material.CLOCK,"§eЧас оновлення: "+storage.refreshTime(id)+" сек.","time:"+id));inv.setItem(14,button(Material.LIME_DYE,"§aОновити лут зараз","refresh:"+id));inv.setItem(16,button(Material.BARRIER,"§cВидалити сундук","remove:"+id));inv.setItem(22,button(Material.ARROW,"§7До списку","back"));p.openInventory(inv);}
 private ItemStack button(Material mat,String name,String action){ItemStack i=new ItemStack(mat);ItemMeta m=i.getItemMeta();m.setDisplayName(name);m.getPersistentDataContainer().set(key,PersistentDataType.STRING,action);i.setItemMeta(m);return i;}
 @EventHandler public void click(InventoryClickEvent e){if(!(e.getWhoClicked() instanceof Player p))return;String title=e.getView().getTitle();if(!title.startsWith("§8TimerCase"))return;e.setCancelled(true);ItemStack item=e.getCurrentItem();if(item==null||!item.hasItemMeta())return;String action=item.getItemMeta().getPersistentDataContainer().get(key,PersistentDataType.STRING);if(action==null)return;if(action.startsWith("case:")){openSettings(p,action.substring(5));}else if(action.equals("create")){p.closeInventory();p.sendMessage("§eПодивись на сундук і введи §f/lootcase create§e.");}else if(action.startsWith("page:")){openMain(p,Integer.parseInt(action.substring(5)));}else if(action.startsWith("loot:")){String id=action.substring(5);editing.put(p.getUniqueId(),id);List<ItemStack> list=storage.loot(id);drafts.put(p.getUniqueId(),new ArrayList<>(list));Inventory inv=Bukkit.createInventory(null,54,"§8TimerCase §7— §fЛут");for(int i=0;i<Math.min(45,list.size());i++)inv.setItem(i,list.get(i).clone());inv.setItem(49,button(Material.EMERALD,"§aЗберегти","save"));inv.setItem(48,button(Material.BARRIER,"§cСкасувати","cancel"));p.openInventory(inv);}else if(action.startsWith("time:")){String id=action.substring(5);storage.refreshTime(id,storage.refreshTime(id)+60);openSettings(p,id);}else if(action.startsWith("refresh:")){String id=action.substring(8);var l=storage.location(id);if(l!=null&&l.getBlock().getState() instanceof org.bukkit.block.Chest c){c.getBlockInventory().clear();List<ItemStack> loot=storage.loot(id);Collections.shuffle(loot);for(ItemStack stack:loot){if(stack!=null)c.getBlockInventory().addItem(stack.clone());}p.sendMessage("§aЛут оновлено.");}openSettings(p,id);}else if(action.startsWith("remove:")){String id=action.substring(7);timers.remove(id);storage.remove(id);openMain(p,0);}else if(action.equals("back")){openMain(p,0);}else if(action.equals("save")){String id=editing.remove(p.getUniqueId());if(id!=null){List<ItemStack> items=new ArrayList<>();Inventory top=e.getView().getTopInventory();for(int i=0;i<45;i++){ItemStack stack=top.getItem(i);if(stack!=null&&stack.getType()!=Material.AIR)items.add(stack.clone());}storage.loot(id,items);drafts.remove(p.getUniqueId());p.sendMessage("§aЛут збережено.");openSettings(p,id);}}else if(action.equals("cancel")){editing.remove(p.getUniqueId());drafts.remove(p.getUniqueId());openMain(p,0);}}
 @EventHandler public void close(InventoryCloseEvent e){if(editing.containsKey(e.getPlayer().getUniqueId())&&e.getView().getTitle().endsWith("Лут")){UUID id=e.getPlayer().getUniqueId();editing.remove(id);drafts.remove(id);}}
}
