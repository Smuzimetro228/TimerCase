package timercase;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import timercase.storage.CaseStorage;
import timercase.manager.TimerManager;
import timercase.gui.CaseGui;
import java.util.Objects;

public final class TimerCasePlugin extends JavaPlugin {
    private CaseStorage storage;
    private TimerManager timers;
    private CaseGui gui;

    @Override public void onEnable() {
        saveDefaultConfig();
        storage = new CaseStorage(this);
        storage.load();
        timers = new TimerManager(this, storage);
        gui = new CaseGui(this, storage, timers);
        Bukkit.getPluginManager().registerEvents(gui, this);
        Bukkit.getPluginManager().registerEvents(timers, this);
        timers.start();
        Objects.requireNonNull(getCommand("lootcase")).setExecutor(this::onCommand);
        getLogger().info("TimerCase увімкнено.");
    }

    @Override public void onDisable() { if (timers != null) timers.shutdown(); if (storage != null) storage.save(); }

    private boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("menu")) {
            if (!(sender instanceof Player p)) { sender.sendMessage("Команда доступна гравцю."); return true; }
            if (!p.hasPermission("timercase.admin")) { p.sendMessage(color(getConfig().getString("messages.no-permission"))); return true; }
            gui.openMain(p, 0); return true;
        }
        if (!sender.hasPermission("timercase.admin")) { sender.sendMessage(color(getConfig().getString("messages.no-permission"))); return true; }
        switch (args[0].toLowerCase()) {
            case "create" -> {
                if (!(sender instanceof Player p)) { sender.sendMessage("Команда доступна гравцю."); return true; }
                Block target = p.getTargetBlockExact(6);
                if (target == null || !(target.getState() instanceof Chest)) { p.sendMessage("&cДивись на звичайний сундук у межах 6 блоків.".replace('&','§')); return true; }
                String id = storage.create(target.getLocation());
                p.sendMessage(color(getConfig().getString("messages.case-created")) + " ID: " + id); return true;
            }
            case "remove" -> {
                if (!(sender instanceof Player p)) return true;
                Block target = p.getTargetBlockExact(6);
                if (target == null) { p.sendMessage("§cНе знайдено блок."); return true; }
                String id = storage.find(target.getLocation());
                if (id == null) p.sendMessage("§cЦе не TimerCase."); else { timers.remove(id); storage.remove(id); storage.save(); p.sendMessage(color(getConfig().getString("messages.case-removed"))); }
                return true;
            }
            case "reload" -> { reloadConfig(); storage.load(); timers.reload(); sender.sendMessage("§aTimerCase: конфігурацію перезавантажено."); return true; }
            case "list" -> { sender.sendMessage("§6TimerCase: §f" + storage.ids().size()); storage.ids().forEach(id -> sender.sendMessage("§7- §f" + id + " §8(" + storage.location(id) + "§8)")); return true; }
            default -> { sender.sendMessage("§e/lootcase menu, create, remove, reload, list"); return true; }
        }
    }
    public static String color(String s) { return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s); }
    public CaseStorage storage() { return storage; }
}
