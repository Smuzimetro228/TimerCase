package timercase.manager;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import org.bukkit.scheduler.BukkitTask;
import timercase.TimerCasePlugin;
import timercase.storage.CaseStorage;
import java.util.*;

public final class TimerManager implements Listener {
    private final TimerCasePlugin plugin; private final CaseStorage storage; private BukkitTask task;
    private final Map<String, UUID> stands=new HashMap<>();
    public TimerManager(TimerCasePlugin p,CaseStorage s){plugin=p;storage=s;}
    public void start(){long period=Math.max(1,plugin.getConfig().getLong("settings.timer-update-interval",20));task=Bukkit.getScheduler().runTaskTimer(plugin,this::tick,period,period);}
    public void shutdown(){if(task!=null)task.cancel();stands.values().forEach(id->{Entity e=Bukkit.getEntity(id);if(e!=null)e.remove();});stands.clear();}
    public void reload(){shutdown();start();}
    public void remove(String id){UUID u=stands.remove(id);if(u!=null){Entity e=Bukkit.getEntity(u);if(e!=null)e.remove();}}
    @EventHandler public void onOpen(InventoryOpenEvent e){if(!(e.getPlayer() instanceof org.bukkit.entity.Player p))return; if(!(e.getInventory().getHolder() instanceof Chest chest))return;String id=storage.find(chest.getLocation());if(id==null||!storage.enabled(id)||!p.hasPermission("timercase.use"))return;if(storage.deadline(id)<=0)storage.deadline(id,System.currentTimeMillis()+storage.refreshTime(id)*1000L);}
    @EventHandler public void onClick(InventoryClickEvent e){ if(!(e.getWhoClicked() instanceof org.bukkit.entity.Player p))return; if(e.getClickedInventory()==null||!(e.getView().getTopInventory().getHolder() instanceof Chest chest))return;String id=storage.find(chest.getLocation());if(id!=null&&storage.enabled(id)&&p.hasPermission("timercase.use")&&storage.deadline(id)<=0)storage.deadline(id,System.currentTimeMillis()+storage.refreshTime(id)*1000L); }
    private void tick(){for(String id:storage.ids()){Location l=storage.location(id);if(l==null||!storage.enabled(id)) {remove(id);continue;}if(!(l.getBlock().getState() instanceof Chest chest)){remove(id);continue;}long end=storage.deadline(id);if(end<=0){remove(id);continue;}long left=end-System.currentTimeMillis();if(left<=0){refresh(id,chest.getBlockInventory());storage.deadline(id,0);remove(id);continue;}updateHologram(id,l,left);}}
    private void refresh(String id,Inventory inv){inv.clear();List<ItemStack> pool=storage.loot(id);if(pool.isEmpty())return;Collections.shuffle(pool);List<Integer> slots=new ArrayList<>();for(int i=0;i<inv.getSize();i++)slots.add(i);Collections.shuffle(slots);int max=Math.min(plugin.getConfig().getInt("settings.max-items-per-refresh",27),Math.min(pool.size(),slots.size()));for(int i=0;i<max;i++)inv.setItem(slots.get(i),pool.get(i).clone());}
    private void updateHologram(String id,Location l,long millis){if(!plugin.getConfig().getBoolean("hologram.enabled",true))return;String time=String.format("%d:%02d",Math.max(0,millis/60000),Math.max(0,(millis/1000)%60));String text=TimerCasePlugin.color(plugin.getConfig().getString("hologram.format","&cОновлення луту: &f%time%").replace("%time%",time));UUID uid=stands.get(id);Entity existing=uid==null?null:Bukkit.getEntity(uid);if(existing instanceof ArmorStand a){a.setCustomName(text);return;}Location at=l.clone().add(.5,plugin.getConfig().getDouble("settings.hologram-height",1.5),.5);ArmorStand a=l.getWorld().spawn(at,ArmorStand.class,stand->{stand.setInvisible(true);stand.setMarker(true);stand.setGravity(false);stand.setCustomNameVisible(true);stand.setCustomName(text);stand.setInvulnerable(true);stand.setPersistent(false);});stands.put(id,a.getUniqueId());}
}
